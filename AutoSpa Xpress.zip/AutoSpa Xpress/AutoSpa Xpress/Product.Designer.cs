﻿using System.Drawing;
namespace AutoSpa_Xpress
{
    partial class Product
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPno = new System.Windows.Forms.Label();
            this.lblMno = new System.Windows.Forms.Label();
            this.lblCname = new System.Windows.Forms.Label();
            this.cmbPno = new System.Windows.Forms.ComboBox();
            this.cmbMno = new System.Windows.Forms.ComboBox();
            this.cmbCname = new System.Windows.Forms.ComboBox();
            this.lblBname = new System.Windows.Forms.Label();
            this.cmbBname = new System.Windows.Forms.ComboBox();
            this.txtDes = new System.Windows.Forms.TextBox();
            this.txtPdes = new System.Windows.Forms.TextBox();
            this.lblDes = new System.Windows.Forms.Label();
            this.lblPdes = new System.Windows.Forms.Label();
            this.lblUnit = new System.Windows.Forms.Label();
            this.txtUnit = new System.Windows.Forms.TextBox();
            this.lblCost = new System.Windows.Forms.Label();
            this.txtCost = new System.Windows.Forms.TextBox();
            this.lblClkr = new System.Windows.Forms.Label();
            this.lblSell = new System.Windows.Forms.Label();
            this.txtSell = new System.Windows.Forms.TextBox();
            this.lblSlkr = new System.Windows.Forms.Label();
            this.txtReOrder = new System.Windows.Forms.TextBox();
            this.lblReOrder = new System.Windows.Forms.Label();
            this.rbStock = new System.Windows.Forms.RadioButton();
            this.rbNStock = new System.Windows.Forms.RadioButton();
            this.rbService = new System.Windows.Forms.RadioButton();
            this.btnNew = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblPno
            // 
            this.lblPno.AutoSize = true;
            this.lblPno.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPno.Location = new System.Drawing.Point(43, 21);
            this.lblPno.Name = "lblPno";
            this.lblPno.Size = new System.Drawing.Size(93, 19);
            this.lblPno.TabIndex = 1;
            this.lblPno.Text = "Product No :";
            // 
            // lblMno
            // 
            this.lblMno.AutoSize = true;
            this.lblMno.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMno.Location = new System.Drawing.Point(50, 54);
            this.lblMno.Name = "lblMno";
            this.lblMno.Size = new System.Drawing.Size(86, 19);
            this.lblMno.TabIndex = 2;
            this.lblMno.Text = "Model No :";
            // 
            // lblCname
            // 
            this.lblCname.AutoSize = true;
            this.lblCname.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCname.Location = new System.Drawing.Point(12, 87);
            this.lblCname.Name = "lblCname";
            this.lblCname.Size = new System.Drawing.Size(124, 19);
            this.lblCname.TabIndex = 3;
            this.lblCname.Text = "Category Name :";
            // 
            // cmbPno
            // 
            this.cmbPno.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbPno.FormattingEnabled = true;
            this.cmbPno.Location = new System.Drawing.Point(142, 18);
            this.cmbPno.Name = "cmbPno";
            this.cmbPno.Size = new System.Drawing.Size(121, 27);
            this.cmbPno.TabIndex = 4;
            this.cmbPno.SelectedIndexChanged += new System.EventHandler(this.cmbPno_SelectedIndexChanged);
            // 
            // cmbMno
            // 
            this.cmbMno.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbMno.FormattingEnabled = true;
            this.cmbMno.Location = new System.Drawing.Point(142, 51);
            this.cmbMno.Name = "cmbMno";
            this.cmbMno.Size = new System.Drawing.Size(160, 27);
            this.cmbMno.TabIndex = 5;
            this.cmbMno.SelectedIndexChanged += new System.EventHandler(this.cmbMno_SelectedIndexChanged);
            this.cmbMno.TextChanged += new System.EventHandler(this.cmbMno_TextChanged);
            // 
            // cmbCname
            // 
            this.cmbCname.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbCname.FormattingEnabled = true;
            this.cmbCname.Location = new System.Drawing.Point(142, 84);
            this.cmbCname.Name = "cmbCname";
            this.cmbCname.Size = new System.Drawing.Size(326, 27);
            this.cmbCname.TabIndex = 6;
            this.cmbCname.SelectedIndexChanged += new System.EventHandler(this.cmbCname_SelectedIndexChanged);
            this.cmbCname.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbCname_KeyPress);
            // 
            // lblBname
            // 
            this.lblBname.AutoSize = true;
            this.lblBname.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBname.Location = new System.Drawing.Point(33, 120);
            this.lblBname.Name = "lblBname";
            this.lblBname.Size = new System.Drawing.Size(103, 19);
            this.lblBname.TabIndex = 7;
            this.lblBname.Text = "Brand Name :";
            // 
            // cmbBname
            // 
            this.cmbBname.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbBname.FormattingEnabled = true;
            this.cmbBname.Location = new System.Drawing.Point(142, 117);
            this.cmbBname.Name = "cmbBname";
            this.cmbBname.Size = new System.Drawing.Size(326, 27);
            this.cmbBname.TabIndex = 8;
            this.cmbBname.SelectedIndexChanged += new System.EventHandler(this.cmbBname_SelectedIndexChanged);
            this.cmbBname.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbBname_KeyPress);
            // 
            // txtDes
            // 
            this.txtDes.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDes.Location = new System.Drawing.Point(143, 150);
            this.txtDes.Name = "txtDes";
            this.txtDes.Size = new System.Drawing.Size(326, 26);
            this.txtDes.TabIndex = 9;
            // 
            // txtPdes
            // 
            this.txtPdes.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPdes.Location = new System.Drawing.Point(142, 182);
            this.txtPdes.Name = "txtPdes";
            this.txtPdes.Size = new System.Drawing.Size(326, 26);
            this.txtPdes.TabIndex = 10;
            // 
            // lblDes
            // 
            this.lblDes.AutoSize = true;
            this.lblDes.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDes.Location = new System.Drawing.Point(41, 154);
            this.lblDes.Name = "lblDes";
            this.lblDes.Size = new System.Drawing.Size(95, 19);
            this.lblDes.TabIndex = 11;
            this.lblDes.Text = "Description :";
            // 
            // lblPdes
            // 
            this.lblPdes.AutoSize = true;
            this.lblPdes.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPdes.Location = new System.Drawing.Point(6, 186);
            this.lblPdes.Name = "lblPdes";
            this.lblPdes.Size = new System.Drawing.Size(131, 19);
            this.lblPdes.TabIndex = 12;
            this.lblPdes.Text = "Print Description :";
            // 
            // lblUnit
            // 
            this.lblUnit.AutoSize = true;
            this.lblUnit.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUnit.Location = new System.Drawing.Point(90, 221);
            this.lblUnit.Name = "lblUnit";
            this.lblUnit.Size = new System.Drawing.Size(46, 19);
            this.lblUnit.TabIndex = 13;
            this.lblUnit.Text = "Unit :";
            // 
            // txtUnit
            // 
            this.txtUnit.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUnit.Location = new System.Drawing.Point(143, 214);
            this.txtUnit.Name = "txtUnit";
            this.txtUnit.Size = new System.Drawing.Size(79, 26);
            this.txtUnit.TabIndex = 14;
            // 
            // lblCost
            // 
            this.lblCost.AutoSize = true;
            this.lblCost.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCost.Location = new System.Drawing.Point(50, 249);
            this.lblCost.Name = "lblCost";
            this.lblCost.Size = new System.Drawing.Size(87, 19);
            this.lblCost.TabIndex = 15;
            this.lblCost.Text = "Cost Price :";
            // 
            // txtCost
            // 
            this.txtCost.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCost.Location = new System.Drawing.Point(143, 246);
            this.txtCost.Name = "txtCost";
            this.txtCost.Size = new System.Drawing.Size(134, 26);
            this.txtCost.TabIndex = 16;
            // 
            // lblClkr
            // 
            this.lblClkr.AutoSize = true;
            this.lblClkr.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblClkr.Location = new System.Drawing.Point(283, 249);
            this.lblClkr.Name = "lblClkr";
            this.lblClkr.Size = new System.Drawing.Size(53, 19);
            this.lblClkr.TabIndex = 17;
            this.lblClkr.Text = "(LKR)";
            // 
            // lblSell
            // 
            this.lblSell.AutoSize = true;
            this.lblSell.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSell.Location = new System.Drawing.Point(36, 281);
            this.lblSell.Name = "lblSell";
            this.lblSell.Size = new System.Drawing.Size(101, 19);
            this.lblSell.TabIndex = 18;
            this.lblSell.Text = "Selling Price :";
            // 
            // txtSell
            // 
            this.txtSell.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSell.Location = new System.Drawing.Point(142, 278);
            this.txtSell.Name = "txtSell";
            this.txtSell.Size = new System.Drawing.Size(134, 26);
            this.txtSell.TabIndex = 19;
            // 
            // lblSlkr
            // 
            this.lblSlkr.AutoSize = true;
            this.lblSlkr.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSlkr.Location = new System.Drawing.Point(283, 285);
            this.lblSlkr.Name = "lblSlkr";
            this.lblSlkr.Size = new System.Drawing.Size(53, 19);
            this.lblSlkr.TabIndex = 20;
            this.lblSlkr.Text = "(LKR)";
            // 
            // txtReOrder
            // 
            this.txtReOrder.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtReOrder.Location = new System.Drawing.Point(142, 310);
            this.txtReOrder.Name = "txtReOrder";
            this.txtReOrder.Size = new System.Drawing.Size(134, 26);
            this.txtReOrder.TabIndex = 21;
            // 
            // lblReOrder
            // 
            this.lblReOrder.AutoSize = true;
            this.lblReOrder.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReOrder.Location = new System.Drawing.Point(25, 313);
            this.lblReOrder.Name = "lblReOrder";
            this.lblReOrder.Size = new System.Drawing.Size(111, 19);
            this.lblReOrder.TabIndex = 22;
            this.lblReOrder.Text = "Re Order Qty :";
            // 
            // rbStock
            // 
            this.rbStock.AutoSize = true;
            this.rbStock.Checked = true;
            this.rbStock.Location = new System.Drawing.Point(47, 360);
            this.rbStock.Name = "rbStock";
            this.rbStock.Size = new System.Drawing.Size(93, 17);
            this.rbStock.TabIndex = 23;
            this.rbStock.TabStop = true;
            this.rbStock.Text = "Stock Product";
            this.rbStock.UseVisualStyleBackColor = true;
            // 
            // rbNStock
            // 
            this.rbNStock.AutoSize = true;
            this.rbNStock.Location = new System.Drawing.Point(175, 360);
            this.rbNStock.Name = "rbNStock";
            this.rbNStock.Size = new System.Drawing.Size(116, 17);
            this.rbNStock.TabIndex = 24;
            this.rbNStock.Text = "Non Stock Product";
            this.rbNStock.UseVisualStyleBackColor = true;
            // 
            // rbService
            // 
            this.rbService.AutoSize = true;
            this.rbService.Location = new System.Drawing.Point(330, 360);
            this.rbService.Name = "rbService";
            this.rbService.Size = new System.Drawing.Size(61, 17);
            this.rbService.TabIndex = 25;
            this.rbService.Text = "Service";
            this.rbService.UseVisualStyleBackColor = true;
            // 
            // btnNew
            // 
            this.btnNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNew.Location = new System.Drawing.Point(24, 404);
            this.btnNew.Name = "btnNew";
            this.btnNew.Size = new System.Drawing.Size(75, 23);
            this.btnNew.TabIndex = 26;
            this.btnNew.Text = "New";
            this.btnNew.UseVisualStyleBackColor = true;
            this.btnNew.Click += new System.EventHandler(this.btnNew_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel.Location = new System.Drawing.Point(112, 404);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 27;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSave
            // 
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(200, 404);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 28;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.Location = new System.Drawing.Point(290, 404);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 23);
            this.btnDelete.TabIndex = 29;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(378, 404);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 30;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // Product
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(481, 447);
            this.ControlBox = false;
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnNew);
            this.Controls.Add(this.rbService);
            this.Controls.Add(this.rbNStock);
            this.Controls.Add(this.rbStock);
            this.Controls.Add(this.lblReOrder);
            this.Controls.Add(this.txtReOrder);
            this.Controls.Add(this.lblSlkr);
            this.Controls.Add(this.txtSell);
            this.Controls.Add(this.lblSell);
            this.Controls.Add(this.lblClkr);
            this.Controls.Add(this.txtCost);
            this.Controls.Add(this.lblCost);
            this.Controls.Add(this.txtUnit);
            this.Controls.Add(this.lblUnit);
            this.Controls.Add(this.lblPdes);
            this.Controls.Add(this.lblDes);
            this.Controls.Add(this.txtPdes);
            this.Controls.Add(this.txtDes);
            this.Controls.Add(this.cmbBname);
            this.Controls.Add(this.lblBname);
            this.Controls.Add(this.cmbCname);
            this.Controls.Add(this.cmbMno);
            this.Controls.Add(this.cmbPno);
            this.Controls.Add(this.lblCname);
            this.Controls.Add(this.lblMno);
            this.Controls.Add(this.lblPno);
            this.Name = "Product";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PRODUCT";
            this.Load += new System.EventHandler(this.Product_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPno;
        private System.Windows.Forms.Label lblMno;
        private System.Windows.Forms.Label lblCname;
        private System.Windows.Forms.ComboBox cmbPno;
        private System.Windows.Forms.ComboBox cmbMno;
        private System.Windows.Forms.ComboBox cmbCname;
        private System.Windows.Forms.Label lblBname;
        private System.Windows.Forms.ComboBox cmbBname;
        private System.Windows.Forms.TextBox txtDes;
        private System.Windows.Forms.TextBox txtPdes;
        private System.Windows.Forms.Label lblDes;
        private System.Windows.Forms.Label lblPdes;
        private System.Windows.Forms.Label lblUnit;
        private System.Windows.Forms.TextBox txtUnit;
        private System.Windows.Forms.Label lblCost;
        private System.Windows.Forms.TextBox txtCost;
        private System.Windows.Forms.Label lblClkr;
        private System.Windows.Forms.Label lblSell;
        private System.Windows.Forms.TextBox txtSell;
        private System.Windows.Forms.Label lblSlkr;
        private System.Windows.Forms.TextBox txtReOrder;
        private System.Windows.Forms.Label lblReOrder;
        private System.Windows.Forms.RadioButton rbStock;
        private System.Windows.Forms.RadioButton rbNStock;
        private System.Windows.Forms.RadioButton rbService;
        private System.Windows.Forms.Button btnNew;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnExit;
    }
}