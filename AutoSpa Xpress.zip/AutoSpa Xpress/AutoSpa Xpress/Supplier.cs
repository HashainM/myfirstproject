﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Configuration;

namespace AutoSpa_Xpress
{
    public partial class Supplier : Form
    {
        OleDbConnection con = new OleDbConnection(ConfigurationManager.ConnectionStrings["AutoSpa_Xpress.Properties.Settings.AutoSpaConnectionString"].ConnectionString);
        OleDbDataAdapter da;

        public Supplier()
        {
            InitializeComponent();
        }

        private void Supplier_Load(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            da = new OleDbDataAdapter("SELECT SUPNO, SUPNAME FROM Suppliers", con);
            da.Fill(dt);
            cmbsupCode.DataSource = dt;
            cmbsupCode.DisplayMember = "SUPNO";
            cmbsupName.DataSource = dt;
            cmbsupName.DisplayMember = "SUPNAME";
            cmbsupCode.Text = null;
            cmbsupName.Text = null;           
            
        }
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            int pi = 0;
            String bCode = null;
            btnNew.Enabled = false;
            btnDelete.Enabled = false;
            cmbsupName.Text = null;
            try
            {
                con.Open();
                OleDbDataReader reader = null;
                OleDbCommand cmd = new OleDbCommand("Select * From Suppliers Where ID = (Select MAX(ID) From Suppliers)", con);
                reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    bCode = reader["SUPNO"].ToString();
                }

                pi = Int32.Parse(bCode);

                if (pi == 0)
                {
                    pi = 1;
                }
                else
                {
                    pi++;
                }

                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("error" + ex);
            }

            cmbsupCode.Text = pi.ToString().PadLeft(6, '0');
            cmbsupCode.Enabled = false;
        }

        

        private void btnSave_Click(object sender, EventArgs e)
        {
            String supCode = cmbsupCode.Text;
            String supName = cmbsupName.Text;
            String conPerson = txtconPerson.Text;
            String Address = txtAddress.Text;
            String City = txtCity.Text;
            String Contact = txtContact.Text;
            String Fax = txtFax.Text;

            try
            {
                OleDbCommand cmd = con.CreateCommand();
                con.Open();
                cmd.CommandText = "INSERT INTO Suppliers (SUPNO,SUPNAME,CONPERSON,SUPADDRESS,SUPCITY,SUPCONTACT,SUPFAX)VALUES('" + supCode + "','" + supName + "','"+conPerson+"','"+Address+"','"+City+"','"+Contact+"','"+Fax+"')";
                cmd.Connection = con;
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERROR " + ex);
            }

            cmbsupCode.Enabled = true;
            cmbsupCode.Text = null;
            cmbsupCode.Items.Clear();
            cmbsupCode.Text = null;
            btnNew.Enabled = true;
            btnDelete.Enabled = true;

            this.Supplier_Load(null, null);
        }

        private void cmbsupCode_SelectedIndexChanged(object sender, EventArgs e)
        {
            ComboBox cb = sender as ComboBox;
            if (cb != null && cmbsupCode.DataSource != null && cmbsupName.DataSource != null)
            {
                int index = cb.SelectedIndex;
                if (index >= 0)
                {
                    if (cmbsupCode.SelectedIndex != index)
                        cmbsupCode.SelectedIndex = index;
                    if (cmbsupName.SelectedIndex != index)
                        cmbsupName.SelectedIndex = index;
                }
            }

        }

        private void cmbsupName_SelectedIndexChanged(object sender, EventArgs e)
        {
            ComboBox cb = sender as ComboBox;
            if (cb != null && cmbsupCode.DataSource != null && cmbsupName.DataSource != null)
            {
                int index = cb.SelectedIndex;
                if (index >= 0)
                {
                    if (cmbsupCode.SelectedIndex != index)
                        cmbsupCode.SelectedIndex = index;
                    if (cmbsupName.SelectedIndex != index)
                        cmbsupName.SelectedIndex = index;
                }
            }
        } 
    }
}
