﻿namespace AutoSpa_Xpress
{
    partial class RegVehicle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbJob = new System.Windows.Forms.GroupBox();
            this.timeJobDate = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.dateJobDate = new System.Windows.Forms.DateTimePicker();
            this.lblJdate = new System.Windows.Forms.Label();
            this.cmbJno = new System.Windows.Forms.ComboBox();
            this.lblJno = new System.Windows.Forms.Label();
            this.gbVehicle = new System.Windows.Forms.GroupBox();
            this.txtNxtMil = new System.Windows.Forms.TextBox();
            this.lblNxtMil = new System.Windows.Forms.Label();
            this.txtInMil = new System.Windows.Forms.TextBox();
            this.lblInMile = new System.Windows.Forms.Label();
            this.txtDays = new System.Windows.Forms.TextBox();
            this.lblDays = new System.Windows.Forms.Label();
            this.cmbMake = new System.Windows.Forms.ComboBox();
            this.lblMake = new System.Windows.Forms.Label();
            this.cmbType = new System.Windows.Forms.ComboBox();
            this.lblType = new System.Windows.Forms.Label();
            this.txtVno = new System.Windows.Forms.TextBox();
            this.lblVno = new System.Windows.Forms.Label();
            this.gbCust = new System.Windows.Forms.GroupBox();
            this.lblEmail = new System.Windows.Forms.Label();
            this.lblFax = new System.Windows.Forms.Label();
            this.lblTel = new System.Windows.Forms.Label();
            this.lblMob = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtFax = new System.Windows.Forms.TextBox();
            this.txtTel = new System.Windows.Forms.TextBox();
            this.txtMob = new System.Windows.Forms.TextBox();
            this.txtAdd = new System.Windows.Forms.TextBox();
            this.lblAdd = new System.Windows.Forms.Label();
            this.dateTimePicker3 = new System.Windows.Forms.DateTimePicker();
            this.txtId = new System.Windows.Forms.TextBox();
            this.lblId = new System.Windows.Forms.Label();
            this.txtCname = new System.Windows.Forms.TextBox();
            this.lblCname = new System.Windows.Forms.Label();
            this.rbExist = new System.Windows.Forms.RadioButton();
            this.rbNew = new System.Windows.Forms.RadioButton();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnNew = new System.Windows.Forms.Button();
            this.gbJob.SuspendLayout();
            this.gbVehicle.SuspendLayout();
            this.gbCust.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbJob
            // 
            this.gbJob.BackColor = System.Drawing.SystemColors.Control;
            this.gbJob.Controls.Add(this.timeJobDate);
            this.gbJob.Controls.Add(this.label2);
            this.gbJob.Controls.Add(this.dateJobDate);
            this.gbJob.Controls.Add(this.lblJdate);
            this.gbJob.Controls.Add(this.cmbJno);
            this.gbJob.Controls.Add(this.lblJno);
            this.gbJob.Location = new System.Drawing.Point(12, 12);
            this.gbJob.Name = "gbJob";
            this.gbJob.Size = new System.Drawing.Size(420, 96);
            this.gbJob.TabIndex = 0;
            this.gbJob.TabStop = false;
            this.gbJob.Text = "Job Details";
            // 
            // timeJobDate
            // 
            this.timeJobDate.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.timeJobDate.Location = new System.Drawing.Point(295, 58);
            this.timeJobDate.Name = "timeJobDate";
            this.timeJobDate.Size = new System.Drawing.Size(96, 20);
            this.timeJobDate.TabIndex = 7;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(233, 63);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 15);
            this.label2.TabIndex = 6;
            this.label2.Text = "In Time :";
            // 
            // dateJobDate
            // 
            this.dateJobDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateJobDate.Location = new System.Drawing.Point(85, 58);
            this.dateJobDate.Name = "dateJobDate";
            this.dateJobDate.Size = new System.Drawing.Size(105, 20);
            this.dateJobDate.TabIndex = 5;
            // 
            // lblJdate
            // 
            this.lblJdate.AutoSize = true;
            this.lblJdate.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblJdate.Location = new System.Drawing.Point(6, 63);
            this.lblJdate.Name = "lblJdate";
            this.lblJdate.Size = new System.Drawing.Size(61, 15);
            this.lblJdate.TabIndex = 4;
            this.lblJdate.Text = "Job Date :";
            // 
            // cmbJno
            // 
            this.cmbJno.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbJno.FormattingEnabled = true;
            this.cmbJno.Location = new System.Drawing.Point(85, 25);
            this.cmbJno.Name = "cmbJno";
            this.cmbJno.Size = new System.Drawing.Size(105, 21);
            this.cmbJno.TabIndex = 3;
            // 
            // lblJno
            // 
            this.lblJno.AutoSize = true;
            this.lblJno.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblJno.Location = new System.Drawing.Point(16, 27);
            this.lblJno.Name = "lblJno";
            this.lblJno.Size = new System.Drawing.Size(51, 15);
            this.lblJno.TabIndex = 2;
            this.lblJno.Text = "Job No :";
            // 
            // gbVehicle
            // 
            this.gbVehicle.Controls.Add(this.txtNxtMil);
            this.gbVehicle.Controls.Add(this.lblNxtMil);
            this.gbVehicle.Controls.Add(this.txtInMil);
            this.gbVehicle.Controls.Add(this.lblInMile);
            this.gbVehicle.Controls.Add(this.txtDays);
            this.gbVehicle.Controls.Add(this.lblDays);
            this.gbVehicle.Controls.Add(this.cmbMake);
            this.gbVehicle.Controls.Add(this.lblMake);
            this.gbVehicle.Controls.Add(this.cmbType);
            this.gbVehicle.Controls.Add(this.lblType);
            this.gbVehicle.Controls.Add(this.txtVno);
            this.gbVehicle.Controls.Add(this.lblVno);
            this.gbVehicle.Location = new System.Drawing.Point(12, 114);
            this.gbVehicle.Name = "gbVehicle";
            this.gbVehicle.Size = new System.Drawing.Size(420, 119);
            this.gbVehicle.TabIndex = 1;
            this.gbVehicle.TabStop = false;
            this.gbVehicle.Text = "Vehicle Details";
            // 
            // txtNxtMil
            // 
            this.txtNxtMil.Location = new System.Drawing.Point(295, 81);
            this.txtNxtMil.Name = "txtNxtMil";
            this.txtNxtMil.Size = new System.Drawing.Size(105, 20);
            this.txtNxtMil.TabIndex = 18;
            // 
            // lblNxtMil
            // 
            this.lblNxtMil.AutoSize = true;
            this.lblNxtMil.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNxtMil.Location = new System.Drawing.Point(203, 86);
            this.lblNxtMil.Name = "lblNxtMil";
            this.lblNxtMil.Size = new System.Drawing.Size(86, 15);
            this.lblNxtMil.TabIndex = 17;
            this.lblNxtMil.Text = "Next Mileage :";
            // 
            // txtInMil
            // 
            this.txtInMil.Location = new System.Drawing.Point(85, 81);
            this.txtInMil.Name = "txtInMil";
            this.txtInMil.Size = new System.Drawing.Size(105, 20);
            this.txtInMil.TabIndex = 16;
            // 
            // lblInMile
            // 
            this.lblInMile.AutoSize = true;
            this.lblInMile.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInMile.Location = new System.Drawing.Point(6, 86);
            this.lblInMile.Name = "lblInMile";
            this.lblInMile.Size = new System.Drawing.Size(72, 15);
            this.lblInMile.TabIndex = 15;
            this.lblInMile.Text = "In Mileage :";
            // 
            // txtDays
            // 
            this.txtDays.Location = new System.Drawing.Point(295, 19);
            this.txtDays.Name = "txtDays";
            this.txtDays.Size = new System.Drawing.Size(38, 20);
            this.txtDays.TabIndex = 14;
            // 
            // lblDays
            // 
            this.lblDays.AutoSize = true;
            this.lblDays.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDays.Location = new System.Drawing.Point(248, 21);
            this.lblDays.Name = "lblDays";
            this.lblDays.Size = new System.Drawing.Size(41, 15);
            this.lblDays.TabIndex = 13;
            this.lblDays.Text = "Days :";
            // 
            // cmbMake
            // 
            this.cmbMake.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.cmbMake.FormattingEnabled = true;
            this.cmbMake.Location = new System.Drawing.Point(295, 50);
            this.cmbMake.Name = "cmbMake";
            this.cmbMake.Size = new System.Drawing.Size(105, 21);
            this.cmbMake.TabIndex = 12;
            // 
            // lblMake
            // 
            this.lblMake.AutoSize = true;
            this.lblMake.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMake.Location = new System.Drawing.Point(244, 56);
            this.lblMake.Name = "lblMake";
            this.lblMake.Size = new System.Drawing.Size(45, 15);
            this.lblMake.TabIndex = 11;
            this.lblMake.Text = "Make :";
            // 
            // cmbType
            // 
            this.cmbType.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.cmbType.FormattingEnabled = true;
            this.cmbType.Location = new System.Drawing.Point(85, 48);
            this.cmbType.Name = "cmbType";
            this.cmbType.Size = new System.Drawing.Size(105, 21);
            this.cmbType.TabIndex = 8;
            // 
            // lblType
            // 
            this.lblType.AutoSize = true;
            this.lblType.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblType.Location = new System.Drawing.Point(40, 56);
            this.lblType.Name = "lblType";
            this.lblType.Size = new System.Drawing.Size(39, 15);
            this.lblType.TabIndex = 10;
            this.lblType.Text = "Type :";
            // 
            // txtVno
            // 
            this.txtVno.Location = new System.Drawing.Point(85, 19);
            this.txtVno.Name = "txtVno";
            this.txtVno.Size = new System.Drawing.Size(105, 20);
            this.txtVno.TabIndex = 9;
            // 
            // lblVno
            // 
            this.lblVno.AutoSize = true;
            this.lblVno.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVno.Location = new System.Drawing.Point(6, 24);
            this.lblVno.Name = "lblVno";
            this.lblVno.Size = new System.Drawing.Size(73, 15);
            this.lblVno.TabIndex = 8;
            this.lblVno.Text = "Vehicle No :";
            // 
            // gbCust
            // 
            this.gbCust.Controls.Add(this.lblEmail);
            this.gbCust.Controls.Add(this.lblFax);
            this.gbCust.Controls.Add(this.lblTel);
            this.gbCust.Controls.Add(this.lblMob);
            this.gbCust.Controls.Add(this.txtEmail);
            this.gbCust.Controls.Add(this.txtFax);
            this.gbCust.Controls.Add(this.txtTel);
            this.gbCust.Controls.Add(this.txtMob);
            this.gbCust.Controls.Add(this.txtAdd);
            this.gbCust.Controls.Add(this.lblAdd);
            this.gbCust.Controls.Add(this.dateTimePicker3);
            this.gbCust.Controls.Add(this.txtId);
            this.gbCust.Controls.Add(this.lblId);
            this.gbCust.Controls.Add(this.txtCname);
            this.gbCust.Controls.Add(this.lblCname);
            this.gbCust.Controls.Add(this.rbExist);
            this.gbCust.Controls.Add(this.rbNew);
            this.gbCust.Location = new System.Drawing.Point(13, 240);
            this.gbCust.Name = "gbCust";
            this.gbCust.Size = new System.Drawing.Size(419, 268);
            this.gbCust.TabIndex = 2;
            this.gbCust.TabStop = false;
            this.gbCust.Text = "Customer Details";
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmail.Location = new System.Drawing.Point(33, 236);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(45, 15);
            this.lblEmail.TabIndex = 32;
            this.lblEmail.Text = "Email :";
            // 
            // lblFax
            // 
            this.lblFax.AutoSize = true;
            this.lblFax.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFax.Location = new System.Drawing.Point(27, 210);
            this.lblFax.Name = "lblFax";
            this.lblFax.Size = new System.Drawing.Size(51, 15);
            this.lblFax.TabIndex = 31;
            this.lblFax.Text = "Fax No :";
            // 
            // lblTel
            // 
            this.lblTel.AutoSize = true;
            this.lblTel.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTel.Location = new System.Drawing.Point(29, 184);
            this.lblTel.Name = "lblTel";
            this.lblTel.Size = new System.Drawing.Size(49, 15);
            this.lblTel.TabIndex = 30;
            this.lblTel.Text = "Tel No :";
            // 
            // lblMob
            // 
            this.lblMob.AutoSize = true;
            this.lblMob.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMob.Location = new System.Drawing.Point(9, 158);
            this.lblMob.Name = "lblMob";
            this.lblMob.Size = new System.Drawing.Size(69, 15);
            this.lblMob.TabIndex = 29;
            this.lblMob.Text = "Mobile No :";
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(84, 234);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(315, 20);
            this.txtEmail.TabIndex = 28;
            // 
            // txtFax
            // 
            this.txtFax.Location = new System.Drawing.Point(84, 208);
            this.txtFax.Name = "txtFax";
            this.txtFax.Size = new System.Drawing.Size(204, 20);
            this.txtFax.TabIndex = 27;
            // 
            // txtTel
            // 
            this.txtTel.Location = new System.Drawing.Point(84, 182);
            this.txtTel.Name = "txtTel";
            this.txtTel.Size = new System.Drawing.Size(204, 20);
            this.txtTel.TabIndex = 26;
            // 
            // txtMob
            // 
            this.txtMob.Location = new System.Drawing.Point(84, 156);
            this.txtMob.Name = "txtMob";
            this.txtMob.Size = new System.Drawing.Size(204, 20);
            this.txtMob.TabIndex = 25;
            // 
            // txtAdd
            // 
            this.txtAdd.Location = new System.Drawing.Point(84, 97);
            this.txtAdd.Multiline = true;
            this.txtAdd.Name = "txtAdd";
            this.txtAdd.Size = new System.Drawing.Size(315, 53);
            this.txtAdd.TabIndex = 24;
            // 
            // lblAdd
            // 
            this.lblAdd.AutoSize = true;
            this.lblAdd.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAdd.Location = new System.Drawing.Point(19, 99);
            this.lblAdd.Name = "lblAdd";
            this.lblAdd.Size = new System.Drawing.Size(59, 15);
            this.lblAdd.TabIndex = 23;
            this.lblAdd.Text = "Address :";
            // 
            // dateTimePicker3
            // 
            this.dateTimePicker3.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker3.Location = new System.Drawing.Point(294, 71);
            this.dateTimePicker3.Name = "dateTimePicker3";
            this.dateTimePicker3.Size = new System.Drawing.Size(105, 20);
            this.dateTimePicker3.TabIndex = 22;
            // 
            // txtId
            // 
            this.txtId.Location = new System.Drawing.Point(84, 71);
            this.txtId.Name = "txtId";
            this.txtId.Size = new System.Drawing.Size(204, 20);
            this.txtId.TabIndex = 21;
            // 
            // lblId
            // 
            this.lblId.AutoSize = true;
            this.lblId.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblId.Location = new System.Drawing.Point(33, 73);
            this.lblId.Name = "lblId";
            this.lblId.Size = new System.Drawing.Size(45, 15);
            this.lblId.TabIndex = 20;
            this.lblId.Text = "ID No :";
            // 
            // txtCname
            // 
            this.txtCname.Location = new System.Drawing.Point(84, 45);
            this.txtCname.Name = "txtCname";
            this.txtCname.Size = new System.Drawing.Size(315, 20);
            this.txtCname.TabIndex = 19;
            // 
            // lblCname
            // 
            this.lblCname.AutoSize = true;
            this.lblCname.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCname.Location = new System.Drawing.Point(33, 47);
            this.lblCname.Name = "lblCname";
            this.lblCname.Size = new System.Drawing.Size(45, 15);
            this.lblCname.TabIndex = 19;
            this.lblCname.Text = "Name :";
            // 
            // rbExist
            // 
            this.rbExist.AutoSize = true;
            this.rbExist.Location = new System.Drawing.Point(246, 19);
            this.rbExist.Name = "rbExist";
            this.rbExist.Size = new System.Drawing.Size(108, 17);
            this.rbExist.TabIndex = 1;
            this.rbExist.TabStop = true;
            this.rbExist.Text = "Existing Customer";
            this.rbExist.UseVisualStyleBackColor = true;
            // 
            // rbNew
            // 
            this.rbNew.AutoSize = true;
            this.rbNew.Checked = true;
            this.rbNew.Location = new System.Drawing.Point(84, 19);
            this.rbNew.Name = "rbNew";
            this.rbNew.Size = new System.Drawing.Size(94, 17);
            this.rbNew.TabIndex = 0;
            this.rbNew.TabStop = true;
            this.rbNew.Text = "New Customer";
            this.rbNew.UseVisualStyleBackColor = true;
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(357, 532);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 35;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.Location = new System.Drawing.Point(270, 532);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 23);
            this.btnDelete.TabIndex = 34;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            // 
            // btnSave
            // 
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(183, 532);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 33;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            // 
            // btnCancel
            // 
            this.btnCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel.Location = new System.Drawing.Point(97, 532);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 32;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            // 
            // btnNew
            // 
            this.btnNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNew.Location = new System.Drawing.Point(12, 532);
            this.btnNew.Name = "btnNew";
            this.btnNew.Size = new System.Drawing.Size(75, 23);
            this.btnNew.TabIndex = 31;
            this.btnNew.Text = "New";
            this.btnNew.UseVisualStyleBackColor = true;
            // 
            // RegVehicle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(444, 580);
            this.ControlBox = false;
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnNew);
            this.Controls.Add(this.gbCust);
            this.Controls.Add(this.gbVehicle);
            this.Controls.Add(this.gbJob);
            this.Name = "RegVehicle";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "VEHICLE REGISTRATION";
            this.Load += new System.EventHandler(this.RegVehicle_Load);
            this.gbJob.ResumeLayout(false);
            this.gbJob.PerformLayout();
            this.gbVehicle.ResumeLayout(false);
            this.gbVehicle.PerformLayout();
            this.gbCust.ResumeLayout(false);
            this.gbCust.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbJob;
        private System.Windows.Forms.Label lblJno;
        private System.Windows.Forms.DateTimePicker dateJobDate;
        private System.Windows.Forms.Label lblJdate;
        private System.Windows.Forms.ComboBox cmbJno;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker timeJobDate;
        private System.Windows.Forms.GroupBox gbVehicle;
        private System.Windows.Forms.TextBox txtVno;
        private System.Windows.Forms.Label lblVno;
        private System.Windows.Forms.ComboBox cmbMake;
        private System.Windows.Forms.Label lblMake;
        private System.Windows.Forms.ComboBox cmbType;
        private System.Windows.Forms.Label lblType;
        private System.Windows.Forms.TextBox txtNxtMil;
        private System.Windows.Forms.Label lblNxtMil;
        private System.Windows.Forms.TextBox txtInMil;
        private System.Windows.Forms.Label lblInMile;
        private System.Windows.Forms.TextBox txtDays;
        private System.Windows.Forms.Label lblDays;
        private System.Windows.Forms.GroupBox gbCust;
        private System.Windows.Forms.RadioButton rbExist;
        private System.Windows.Forms.RadioButton rbNew;
        private System.Windows.Forms.Label lblCname;
        private System.Windows.Forms.TextBox txtAdd;
        private System.Windows.Forms.Label lblAdd;
        private System.Windows.Forms.DateTimePicker dateTimePicker3;
        private System.Windows.Forms.TextBox txtId;
        private System.Windows.Forms.Label lblId;
        private System.Windows.Forms.TextBox txtCname;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Label lblFax;
        private System.Windows.Forms.Label lblTel;
        private System.Windows.Forms.Label lblMob;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.TextBox txtFax;
        private System.Windows.Forms.TextBox txtTel;
        private System.Windows.Forms.TextBox txtMob;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnNew;
    }
}