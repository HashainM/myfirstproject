﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace AutoSpa_Xpress
{
    public partial class Login : Form
    {
        OleDbConnection con = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=AutoSpa.mdb");  

        public Login()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                String uname = txtUsername.Text;                
                con.Open();
                OleDbDataReader reader = null;
                OleDbCommand cmd = new OleDbCommand("Select * From Users Where UserName='"+uname+"'", con);
                reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    String password = reader["Password"].ToString();
                    if (txtPwd.Text.Equals(password))
                    {
                        MessageBox.Show("Login Successful");
                        this.Close();
                        Form1.mdiobj.FileMenu.Enabled = true;
                    }
                    else
                    {
                        MessageBox.Show("Invalid Login","Login Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
                        txtPwd.Text = null;
                    }
                }
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("error " + ex);
            }

        }       

        private void txtPwd_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
               try
                {
                    String uname = txtUsername.Text;
                    con.Open();
                    OleDbDataReader reader = null;
                    OleDbCommand cmd = new OleDbCommand("Select * From Users Where UserName='" + uname + "'", con);
                    reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        String password = reader["Password"].ToString();
                        if (txtPwd.Text.Equals(password))
                        {
                            MessageBox.Show("Login Successful");
                            this.Close();
                            Form1.mdiobj.FileMenu.Enabled = true;
                        }
                        else
                        {
                            MessageBox.Show("Invalid Login", "Login Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            txtPwd.Text = null;
                        }
                    }
                    con.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("error " + ex);
                    
                }
            }
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }        
              
    }
}
