﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace AutoSpa_Xpress
{
    public partial class Form1 : Form        
    {
        
        public static Form1 mdiobj;

        private Brands brand;
        private Category cat;
        private Product product;
        private RegVehicle vehicle;
        private Sales sales;
        private Supplier supplier;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            FileMenu.Enabled = true;
            Login loginScreen = new Login();
            loginScreen.Show();
            loginScreen.MdiParent = this;
            mdiobj = this;              
        }

        private void BrandsMenuItem_Click(object sender, EventArgs e)
        {
            if (brand != null)
            {
                brand.WindowState = FormWindowState.Normal;
                brand.Focus();
            }
            else
            {
                brand = new Brands();
                brand.MdiParent = this;
                brand.FormClosed += (o, ea) => brand = null;
                brand.Show();
            }
        }

        private void CategoryMenuItem_Click(object sender, EventArgs e)
        {
            if (cat != null)
            {
                cat.WindowState = FormWindowState.Normal;
                cat.Focus();
            }
            else
            {
                cat = new Category();
                cat.MdiParent = this;
                cat.FormClosed += (o, ea) => cat = null;
                cat.Show();
            }
        }

        private void productMenuItem_Click(object sender, EventArgs e)
        {
            if (product != null)
            {
                product.WindowState = FormWindowState.Normal;
                product.Focus();
            }
            else
            {
                product = new Product();
                product.MdiParent = this;
                product.FormClosed += (o, ea) => product = null;
                product.Show();
            }
        }

        private void vehicleRegistrationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (vehicle != null)
            {
                vehicle.WindowState = FormWindowState.Normal;
                vehicle.Focus();
            }
            else
            {
                vehicle = new RegVehicle();
                vehicle.MdiParent = this;
                vehicle.FormClosed += (o, ea) => vehicle = null;
                vehicle.Show();
            }

        }

        private void salesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (sales != null)
            {
                sales.WindowState = FormWindowState.Normal;
                sales.Focus();
            }
            else
            {
                sales = new Sales();
                sales.MdiParent = this;
                sales.FormClosed += (o, ea) => sales = null;
                sales.Show();
            }
        }

        private void supplierToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (supplier != null)
            {
                supplier.WindowState = FormWindowState.Normal;
                supplier.Focus();
            }
            else
            {
                supplier = new Supplier();
                supplier.MdiParent = this;
                supplier.FormClosed += (o, ea) => supplier = null;
                supplier.Show();
            }
        }
        
    }
}
