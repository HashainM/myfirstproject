﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace AutoSpa_Xpress
{
    public partial class RegVehicle : Form
    {
        public RegVehicle()
        {
            InitializeComponent();
        }

        private void RegVehicle_Load(object sender, EventArgs e)
        {
            dateJobDate.Format = DateTimePickerFormat.Custom;
            dateJobDate.CustomFormat = "dd-MMM-yyyy";

            timeJobDate.Format = DateTimePickerFormat.Time;
            timeJobDate.ShowUpDown = true;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
              
            
    }
}
