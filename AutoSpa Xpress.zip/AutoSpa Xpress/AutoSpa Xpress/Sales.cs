﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace AutoSpa_Xpress
{
    public partial class Sales : Form
    {
        public Sales()
        {
            InitializeComponent();
        }

        private void Sales_Load(object sender, EventArgs e)
        {
            dateTimePicker1.Format = DateTimePickerFormat.Custom;
            dateTimePicker1.CustomFormat = "dd-MMM-yyyy";

            dateTimePicker2.Format = DateTimePickerFormat.Time;
            dateTimePicker2.ShowUpDown = true;

            dataGridView1.Columns[0].Width = 100;
            dataGridView1.Columns[1].Width = 100;
            dataGridView1.Columns[2].Width = 200;
            dataGridView1.Columns[3].Width = 80;
            dataGridView1.Columns[4].Width = 54;
            dataGridView1.Columns[5].Width = 50;
            dataGridView1.Columns[6].Width = 50;

            dataGridView2.Columns[0].Width = 75;
            dataGridView2.Columns[1].Width = 215;
            dataGridView2.Columns[2].Width = 50;
            dataGridView2.Columns[3].Width = 75;

            dataGridView4.Columns[0].Width = 100;
            dataGridView4.Columns[1].Width = 315;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
              
    }
}
